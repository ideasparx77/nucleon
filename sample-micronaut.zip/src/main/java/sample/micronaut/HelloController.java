package sample.micronaut;

import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;

@Controller
public class HelloController {

    @Get("/hello")
    public HttpResponse<?> index() {
        return HttpResponse.ok("Hi there!");
    }

    @Get("/health")
    public HttpResponse<?> health() {
        return HttpResponse.ok(new HealthMessage("GREEN"));
    }

    public class HealthMessage {

        final String status;

        public HealthMessage(final String content) {
            this.status = content;
        }

        public String getStatus() {
            return status;
        }

    }
}
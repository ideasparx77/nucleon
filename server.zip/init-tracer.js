const jaeger = require('jaeger-client');
const opentracing = require('opentracing');
var initTracer = jaeger.initTracer;

// See schema https://github.com/jaegertracing/jaeger-client-node/blob/master/src/configuration.js#L37
var config = {
    serviceName: 'DOX Service',
    sampler: { type: 'const', param: 1 }
};
var options = {
    tags: {
        'DOX Service': '1.0.0',
    }
};

var tracer = initTracer(config, options);

module.exports = {
    tracer,
    opentracing,
    jaeger
};
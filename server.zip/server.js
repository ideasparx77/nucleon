var { tracer, opentracing, jaeger } = require('./init-tracer.js');

// store a reference to the original request function
const http = require('http');
const originalRequest = http.request;
var mainSpan = null;

// override the function
http.request = function wrapMethodRequest(...args) {
    var req = args[0];
    var span = null;

    if (mainSpan) {
        span = tracer.startSpan("child", opentracing.childOf(mainSpan));
    } else {
        span = tracer.startSpan("http_request");
    }

    span.addTags({
        "http.request": JSON.stringify({
            query: req.query,
            headers: req.headers
        })
    });

    if (args[1]) {
        var origCallback = args[1];
        args[1] = function (res) {
            var body = "";
            res.on('readable', function () {
                body += res.read();
            });
            res.on('end', function () {
                span.addTags({ "http.response_body": body });
            });
            span.addTags({
                "http.response": JSON.stringify({
                    statusCode: res.statusCode,
                    headers: req.headers,
                    statusMessage: req.statusMessage
                })
            });

            return origCallback(res);
        }
    }

    return originalRequest.apply(this, args);
}

// const Tracer = require('@risingstack/jaeger')
// const tracerO = new Tracer({
//     serviceName: 'DOX service',
//     sampler: new (require('jaeger-client').ConstSampler)(true)
// });
// const tracer = tracerO._tracer;

const Keycloak = require('keycloak-connect');
const express = require('express');
const app = express();
const config = require('./config.json');

var session = require('express-session');
var memoryStore = new session.MemoryStore();
var keycloak = new Keycloak({ store: memoryStore });

app.use(keycloak.middleware());
app.use((req, res, next) => {
    mainSpan = tracer.startSpan("john-generic-tracer");
    next();
});

app.get('/', keycloak.enforcer('/v1/document/*'), (req, res) => {

    mainSpan.finish();
    mainSpan = null;

    res.json({
        "data": "Hello world!"
    });

});

var port = config.port || 10000;
app.listen(port, () => console.log(`App listening on port ${port}!`));
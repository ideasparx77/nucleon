const tf = require('@tensorflow/tfjs-node-gpu');
const word2vec = require('./word2vec');

const wordVecFile = './word2vec.json';
const modelFile = 'file://./model.json/model.json';

word2vec.load(wordVecFile);
const categories = word2vec.getCategories();

function getCategoryName(index) {
    for (var k in categories) {
        if (categories[k] === index) {
            return k;
        }
    }
}

async function main() {

    var model = await tf.loadLayersModel(modelFile);
    var text = 'profile: david miliband david miliband s rapid rise through the ranks of government continues with his promotion to cabinet office minister.  elected in a safe labour seat in 2001 his previous job was school standards minister - a role he won in may 2002. prior to the last election he was a key figure in new labour as the head of the downing street policy unit where he was a key member of the manifesto writing team. seen as one of the more intellectual figures in the government  he was also working for tony blair in his policy unit when he was leader of the opposition.  a brief glance at mr miliband s family background reveals an impressive socialist pedigree in the form of his father ralph  who died in 1994. he was an eminent and influential leftwing academic. and while david miliband is seen as a key blair lieutenant his brother ed is a special advisor to chancellor gordon brown. prior to working for mr blair  david miliband spent time at the left-leaning institute for public policy research. he then became secretary of the commission on social justice. the 39-year-old was educated at haverstock comprehensive before going on to oxford to study politics  philosophy and economics. he also took an msc in political science from the massachusetts institute of technology.';
    var features = word2vec.encode(text, 1000);
    var data = tf.tensor2d(features, [1, 1000]);
    var result = (await model.predict(data).array())[0];

    var maxIndex = result.indexOf(Math.max(...result));

    console.log(result);
    console.log(`Category is : ${getCategoryName(maxIndex)}`);
}

main();

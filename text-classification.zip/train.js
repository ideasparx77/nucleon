const tf = require('@tensorflow/tfjs-node-gpu');
const word2vec = require('./word2vec');
const fs = require('fs');

async function main() {

    const tensorboardDir = './_tensorboard/' + new Date().toISOString().replace(/[^_a-zA-Z0-9-+]/gi, "_");
    const wordVecFile = './word2vec.json';

    console.log(tf.version);

    var data = await tf.data.csv('file://./bbc-text.csv', {
        hasHeader: true,
        columnConfigs: {
            category: {
                isLabel: true
            }
        }
    });

    if (fs.existsSync(wordVecFile)) {
        word2vec.load(wordVecFile);
    } else {
        var docCount = 0;
        await data.forEachAsync(e => {
            word2vec.addDocument(e.xs['text'], e.ys['category']);
            docCount++;
        });

        word2vec.save(wordVecFile);
    }

    var categories = word2vec.getCategories(data);
    var wordvec = word2vec.getWordVectors();

    console.log("Vocabulary: " + Object.keys(wordvec).length);

    var freq = word2vec.getWordFrequency();
    console.log(freq.slice(0, 100));

    console.log(await data.columnNames());

    var model = tf.sequential();
    //model.add(tf.layers.dense({ inputShape: [1000], units: 50, activation: 'selu' }));
    model.add(tf.layers.embedding({ inputDim: word2vec.maxId, outputDim: 128, inputLength: 1000 }));
    model.add(tf.layers.dropout({ rate: 0.2 }));
    model.add(tf.layers.conv1d({ filters: 128, kernelSize: 2, padding: 'valid', activation: 'selu', strid: 1 }));
    model.add(tf.layers.globalMaxPooling1d());
    model.add(tf.layers.dense({ units: 512, activation: 'selu' }));
    model.add(tf.layers.dropout({ rate: 0.2 }));
    model.add(tf.layers.dense({ units: Object.keys(categories).length, activation: 'softmax' }));

    model.compile({ optimizer: 'adam', loss: 'sparseCategoricalCrossentropy', metrics: ['accuracy'] });

    model.summary();

    data = data.map(row => {
        const rawFeatures = row['xs']["text"];
        const rawLabel = row['ys'];
        const convertedFeatures = word2vec.encode(rawFeatures, 1000);
        const convertedLabel = [categories[rawLabel['category']]];
        return { xs: tf.tensor1d(convertedFeatures), ys: tf.tensor1d(convertedLabel) };
    });

    const batchSize = 100;
    const epochs = 10;// Math.ceil(docCount / batchSize);
    const trainBatches = Math.floor(docCount * 0.8 / batchSize);

    data = data.shuffle(batchSize * 3).batch(batchSize);
    var trainData = data.take(trainBatches);
    var valData = data.skip(trainBatches);

    console.log(`Batch size: ${batchSize}, epochs: ${epochs}`);
    await model.fitDataset(trainData, {
        epochs: epochs,
        validationData: valData,
        callbacks: tf.node.tensorBoard(tensorboardDir, { updateFreq: 'batch' })
    });

    const saveResults = await model.save('file://./model.json');

    console.log('training completed.');
}

main();
const natural = require('natural');
const tokenizer = new natural.WordTokenizer();
const fs = require('fs');

class Word2Vec {
    constructor() {
        this.maxId = 1;
        this.wordvec = {};
        this.wordfreq = {};
        this.categories = {};
    }

    getCategories() {
        var obj = this.categories;
        if (Object.keys(obj).length > 0 && obj[Object.keys(obj)[0]] === -1) {
            var i = 0;
            for (var c in this.categories) {
                this.categories[c] = i++;
            }
        }
        return this.categories;
    }

    save(filename) {
        this.getCategories();

        var data = {
            maxId: this.maxId,
            wordvec: this.wordvec,
            wordfreq: this.wordfreq,
            categories: this.categories
        }

        fs.writeFile(filename, JSON.stringify(data), 'utf8', err => {
            if (err) { console.error(err); }
        });
    }

    load(filename) {
        var data = fs.readFileSync(filename, 'utf8', err => {
            if (err) { console.error(err); }
        });
        data = JSON.parse(data);
        this.maxId = data.maxId;
        this.wordvec = data.wordvec;
        this.wordfreq = data.wordfreq;
        this.categories = data.categories;
    }

    encode(text, length) {
        var tokens = tokenizer.tokenize(text);
        tokens = tokens.map(t => {
            var t2 = natural.PorterStemmer.stem(t) || t;
            //var vec = (this.wordvec[t2] || 0) / this.maxId;
            var vec = (this.wordvec[t2] || 0);
            return vec;
        });

        if (length) {
            if (tokens.length > length) {
                tokens = tokens.slice(0, length);
            } else if (tokens.length < length) {
                tokens = tokens.concat(Array(length - tokens.length).fill(0));
            }
        }

        return tokens;
    }

    addDocument(text, category) {
        this.categories[category] = -1;
        var tokens = tokenizer.tokenize(text);
        tokens = tokens.map(t => {
            var t2 = natural.PorterStemmer.stem(t) || t;
            this.addWord(t2);
            return t2;
        });
        return tokens;
    }

    getWordVectors() {
        return this.wordvec;
    }

    getWordFrequency() {
        var a = [];
        for (var k in this.wordfreq) {
            a.push([k, this.wordfreq[k]]);
        }

        a.sort((x, y) => {
            return y[1] - x[1];
        });

        return a;
    }

    addWord(word) {
        if (!(word in this.wordvec)) {
            this.wordvec[word] = this.maxId++;
        }

        if (!(word in this.wordfreq)) {
            this.wordfreq[word] = 1;
        } else {
            this.wordfreq[word]++;
        }
    }
}

module.exports = new Word2Vec();